Drag Master - native Android project (Kotlin + WebView)
Author: Erfan Ghaffari

1) Copy your game file index-8.html to:
   app/src/main/assets/index.html   (replace the placeholder, keep the name index.html)
   If the game has other files (images, sounds), put them in the same assets folder.
2) Open this folder in Android Studio (File > Open), wait for Gradle sync.
3) Build > Build APK(s)  ->  app/build/outputs/apk/debug/app-debug.apk
   For a signed release: Build > Generate Signed App Bundle / APK > APK.
Notes:
 - Landscape is forced. For portrait/auto change android:screenOrientation in AndroidManifest.xml
   ("portrait" or "unspecified").
 - App name: res/values/strings.xml. Package id: ir.erfan.dragmaster (app/build.gradle.kts).
